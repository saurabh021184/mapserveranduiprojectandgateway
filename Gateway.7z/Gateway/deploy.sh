#! /usr/bin/env bash

docker stack deploy -c docker-compose.yml imap-gateway
