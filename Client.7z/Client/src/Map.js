import React, { useRef, useEffect, useState } from 'react';
import mapboxgl from 'mapbox-gl'
import './Map.css';
import 'mapbox-gl/dist/mapbox-gl.css';

const Map = () => {
  const mapContainerRef = useRef(null);

  const [lng, setLng] = useState(-72.66);
  const [lat, setLat] = useState(41.76);
  const [zoom, setZoom] = useState(10);

  // Initialize map when component mounts
  useEffect(() => {
    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: 'http://10.10.26.152/imap/apis/resources/styles/style.json',
      center: [lng, lat],
      hash: true,
      zoom: zoom
    });

    // Add navigation control (the +/- zoom buttons)
    map.addControl(new mapboxgl.NavigationControl(), 'top-right');

    map.on('move', () => {
      setLng(map.getCenter().lng.toFixed(4));
      setLat(map.getCenter().lat.toFixed(4));
      setZoom(map.getZoom().toFixed(2));
    });

    // Clean up on unmount
    return () => map.remove();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div>
      <div className='sidebarStyle'>
        <div>
          Longitude: {lng} | Latitude: {lat} | Zoom: {zoom}
        </div>
      </div>
      <div className='map-container'>
        <div className='psap-map' ref={mapContainerRef} />
      </div>
    </div>
  );
};

export default Map;
