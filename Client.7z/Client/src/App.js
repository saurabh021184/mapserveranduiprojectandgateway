import React from 'react';
import Map from './Map';

function App() {
  return (
    <div>
      <Map />
    </div>
  );
}

export default App;
