#! /usr/bin/env bash

docker build -t imap .
